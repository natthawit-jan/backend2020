package com.natwit442.project1.natwit442project1

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class Natwit442Project1Application

fun main(args: Array<String>) {
	runApplication<Natwit442Project1Application>(*args)
}
