package com.natwit442.project1.natwit442project1

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class Natwit442Project1ApplicationTests {

	@Test
	fun contextLoads() {
	}

}
